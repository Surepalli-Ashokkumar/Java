package com.cisco.RestApiDemoAssignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
