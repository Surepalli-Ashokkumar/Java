package com.cisco.RestApiDemoAssignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestApiAssignmentApplication.class, args);
	}

}
