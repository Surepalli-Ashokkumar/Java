package com.cisco.travelManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
