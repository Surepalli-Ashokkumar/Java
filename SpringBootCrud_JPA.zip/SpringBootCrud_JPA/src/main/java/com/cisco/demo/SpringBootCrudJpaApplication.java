package com.cisco.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCrudJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCrudJpaApplication.class, args);
	}

}
